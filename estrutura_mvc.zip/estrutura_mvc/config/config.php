<?php

define("SERVIDOR", "localhost");
define("BANCO", "portoseguro_paginacao");
define("USUARIO", "root");
define("SENHA", "");


define('CONTROLLER_PADRAO', 'index');
define('METODO_PADRAO', 'index');
define('NAMESPACE_CONTROLLER', 'app\\controllers\\');

define('URL_BASE', 'http://localhost/estrutura_mvc/');
