<?php
namespace app\controllers;

class IndexController{
    
   public function index(){
       echo "<br>Controller padrão<br>";
   } 
}
