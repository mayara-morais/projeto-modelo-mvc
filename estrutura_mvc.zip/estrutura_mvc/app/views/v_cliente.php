<!DOCTYPE html>
<html>
<head>
	<title>Curso de MVC</title>
</head>
<body>

<h1> Curso de MVC - mjailton </h1>
<p>Estamos estudando PHP.</p>
<?php 
    foreach($clientes as $cliente){
        echo $cliente["cliente"] ."<br>";
    }

?>
</body>
</html>




