<!DOCTYPE html>
<html>
<head>
	<title>Curso de MVC</title>
</head>
<body>

<h1> View Produto </h1>
<p>Estamos estudando PHP.</p>

</body>
</html>




